import json
import numpy as np
import pandas as pd
from tqdm import tqdm
import torch

# path = "data/games_processed.csv"
# data = pd.read_csv(path)
# for index, game in tqdm(data.iterrows(), total=data.shape[0]):
#     print(index)
#     print((game.array[0]))
#     break

print(torch.tensor(5))
