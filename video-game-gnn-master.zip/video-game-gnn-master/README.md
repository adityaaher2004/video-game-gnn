# video-game-gnn
Creating a sophisticated video game recommendation system using graph neural networks
